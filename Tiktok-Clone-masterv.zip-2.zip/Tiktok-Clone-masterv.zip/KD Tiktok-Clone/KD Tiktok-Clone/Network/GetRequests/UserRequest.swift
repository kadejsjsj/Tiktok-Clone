//
//  UserRequest.swift
//  KD Tiktok-Clone
//
//  Created by Sam Ding on 9/20/20.
//  Copyright © 2020 Kaishan. All rights reserved.
//

import Foundation
import Firebase

class UserRequest: NetworkModel {
    
}
